pip install "causal-conv1d>=1.2.0"
pip install triton==3.2.0
python setup.py install